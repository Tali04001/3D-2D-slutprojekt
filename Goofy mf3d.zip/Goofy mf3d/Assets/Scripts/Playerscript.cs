﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playerscript : MonoBehaviour
{
    [SerializeField]
    private GameObject _laserPrefab; //anropar laser prefab
    [SerializeField]
    private float _fireRate = 0.5f;
    private float _canFire = -1f;
    [SerializeField]
    private int _lives = 3;
    private Spawn _spawnManager;
  

    void Start()
    {
        transform.position = new Vector3(-14, 0, 0);
        _spawnManager = GameObject.Find("Spawn_manager").GetComponent<Spawn>();
        
    
    }

    // Update is called once per frame
    void Update()
    {
       CalculateMovement();

       if(Input.GetKeyDown(KeyCode.Space) && Time.time > _canFire)
       {
           _canFire =Time.time + _fireRate;

           Instantiate(_laserPrefab, transform.position + new Vector3(1f, 0, 0), Quaternion.identity);

           
       }
    }
    void CalculateMovement(){

        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        transform.Translate(new Vector3(horizontalInput, verticalInput, 0) * 10f * Time.deltaTime);

        if(transform.position.y >=8.8f){

            transform.position = new Vector3(transform.position.x, 8.8f, 0);
        }
        else if(transform.position.y <= -6.8f){
            transform.position = new Vector3(transform.position.x, -6.8f, 0);

        }

     if(transform.position.x > 14.1f){
       
        transform.position = new Vector3(14.1f, transform.position.y, 0); //eftersom 3d Vector3 det här är den nya positionen 
     }
     else if(transform.position.x < -14.1f){

        transform.position = new Vector3(-14.1f, transform.position.y, 0);
       }

    }
    
    public void Damage(){
        _lives -= 1;

        if(_lives < 1){
            
            _spawnManager.OnPlayerDeath();
            Destroy(this.gameObject);

        }
    }
}
    